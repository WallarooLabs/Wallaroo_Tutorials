# Expose these types/functions to the user
import sys
from importlib.metadata import version as v

from . import expression, functions, notify
from .client import Client
from .deployment_config import DeploymentConfigBuilder

# This ternary allows us to run pytest without installing the module.
__version__ = (
    v(__package__)
    if "pytest" not in sys.modules and "unittest" not in sys.modules
    else "0.0.0"
)


def version():
    return __version__
