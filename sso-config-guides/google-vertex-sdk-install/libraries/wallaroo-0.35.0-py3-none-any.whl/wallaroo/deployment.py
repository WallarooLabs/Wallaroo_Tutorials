import asyncio
import json
import pathlib
import sys
import time
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Tuple,
    Union,
    cast,
)

import aiohttp
import gql  # type: ignore
import orjson
import requests
from IPython.display import HTML, display  # type: ignore
from requests.adapters import HTTPAdapter, Retry

from .auth import _PlatformAuth
from .inference_result import InferenceResult
from .logs import LogEntries
from .model_config import ModelConfig
from .object import *
from .wallaroo_ml_ops_api_client.api.pipeline import pipelines_undeploy
from .wallaroo_ml_ops_api_client.models import pipelines_undeploy_json_body
from .wallaroo_ml_ops_api_client.types import UNSET

if TYPE_CHECKING:
    from .client import Client
    from .model import Model
    from .pipeline_variant import PipelineVariant


class WaitForError(Exception):
    def __init__(self, message: str, status: Optional[Dict[str, Any]]):
        super().__init__(message)
        self.status = status


class WaitForDeployError(RuntimeError):
    def __init__(self, message: str):
        super().__init__(message)

    def _render_traceback_(self):
        display(
            HTML(
                "<strong>*** An error occurred while deploying your pipeline.</strong>"
            )
        )
        return [str(self)]


class Deployment(Object):
    def __init__(self, client: Optional["Client"], data: Dict[str, Any]) -> None:
        self.client = client
        assert client is not None
        # TODO: revisit session initialization during connection pooling work
        self.session = self._initialize_session()
        super().__init__(gql_client=client._gql_client, data=data)

    def _fill(self, data: Dict[str, Any]) -> None:
        """Fills an object given a response dictionary from the GraphQL API.

        Only the primary key member must be present; other members will be
        filled in via rehydration if their corresponding member function is
        called.
        """
        from .pipeline_variant import PipelineVariant  # avoids circular imports

        for required_attribute in ["id"]:
            if required_attribute not in data:
                raise RequiredAttributeMissing(
                    self.__class__.__name__, required_attribute
                )
        self._id = data["id"]

        self._name = value_if_present(data, "deploy_id")
        self._deployed = value_if_present(data, "deployed")
        self._model_configs = (
            [
                ModelConfig(self.client, elem["model_config"])
                for elem in data["deployment_model_configs"]
            ]
            if "deployment_model_configs" in data
            else DehydratedValue()
        )
        self._pipeline_variants = (
            [
                PipelineVariant(self.client, elem["pipeline_version"])
                for elem in data["deployment_pipeline_versions"]
            ]
            if "deployment_pipeline_versions" in data
            else DehydratedValue()
        )

        self._pipeline_id = value_if_present(data, "pipeline_id")

    def _fetch_attributes(self) -> Dict[str, Any]:
        """Fetches all member data from the GraphQL API."""
        return self._gql_client.execute(
            gql.gql(
                """
            query DeploymentById($deployment_id: bigint!) {
                deployment_by_pk(id: $deployment_id) {
                    id
                    deploy_id
                    deployed
                    deployment_model_configs {
                        model_config {
                            id
                        }
                    }
                    deployment_pipeline_versions(order_by: {pipeline_version: {id: desc}}) {
                        pipeline_version {
                            id
                        }
                    }
                }
            }
            """
            ),
            variable_values={
                "deployment_id": self._id,
            },
        )["deployment_by_pk"]

    def _initialize_session(self) -> requests.Session:
        # TODO: make session initialization configurable
        #  to be informed by connection polling reqs.
        #  includes sane defaults to match current retry time (~45s)
        session = requests.Session()
        retries = Retry(
            total=10,
            backoff_factor=0.1,
            status_forcelist=[503],
            allowed_methods=["GET", "POST"],
        )
        session.mount("http://", HTTPAdapter(max_retries=retries))
        return session

    def id(self) -> int:
        return self._id

    @rehydrate("_name")
    def name(self) -> str:
        return cast(str, self._name)

    @rehydrate("_deployed")
    def deployed(self) -> bool:
        return cast(bool, self._deployed)

    @rehydrate("_model_configs")
    def model_configs(self) -> List[ModelConfig]:
        return cast(List[ModelConfig], self._model_configs)

    @rehydrate("_pipeline_variants")
    def pipeline_variants(self) -> List["PipelineVariant"]:
        from .pipeline_variant import PipelineVariant  # avoids circular imports

        return cast(List[PipelineVariant], self._pipeline_variants)

    def deploy(self) -> "Deployment":
        """Deploys this deployment, if it is not already deployed.

        If the deployment is already deployed, this is a no-op.
        """
        q = gql.gql(
            """
        mutation Deploy($id: bigint!) {
            update_deployment_by_pk(pk_columns: {id: $id} _set: { deployed: true }) {
                id
                deploy_id
                deployed
            }
        }
        """
        )
        variables = {"id": self.id()}
        assert self.client is not None
        self.client._gql_client.execute(q, variable_values=variables)
        self._rehydrate()
        return self

    def undeploy(self) -> "Deployment":
        """Shuts down this deployment, if it is deployed.

        If the deployment is already undeployed, this is a no-op.
        """
        # TODO: Error handling.
        assert self.client is not None

        data = pipelines_undeploy.sync_detailed(
            client=self.client.mlops(),
            json_body=pipelines_undeploy_json_body.PipelinesUndeployJsonBody(
                UNSET, self.id()
            ),
        )

        if data.status_code != 200:
            err = data.content.decode("utf-8")
            raise Exception(f"Failed to undeploy. {err}")

        self._rehydrate()
        return self.wait_for_undeployed()

    def _get_auth(self):
        # TODO: Digging the auth object out of the gql_client is cheating
        return self.client._gql_client.transport.auth

    def status(self) -> Dict[str, Any]:
        """Returns a dict of deployment status useful for determining if a deployment has succeeded.

        :return: Dict of deployment internal state information.
        :rtype: Dict[str, Any]
        """

        assert self.client is not None

        status_url = f"{self.client.api_endpoint}/v1/api/status/get_deployment"
        params = {"name": f"{self.name()}-{self.id()}"}

        kind = ""
        resp = None
        try:
            resp = requests.post(
                status_url,
                timeout=5,
                auth=self._get_auth(),
                json=params,
            )
            kind = ""
        except requests.ReadTimeout as ex:
            raise CommunicationError(f"rest-api connection to {status_url}")
        except Exception:
            kind = "comm"

        if resp is not None and resp.status_code == 200:
            res = resp.json()
            if res is not None and res["status"] == "Running":
                # retry for a running status
                return res

        details = ""
        if resp is not None:
            if resp.status_code == 200:
                return resp.json()

            if resp.status_code == 404:
                raise EntityNotFoundError(
                    f"Deployment not found", {"name": self.name()}
                )

            details = f"\nStatus code: {resp.status_code}\nMessage: {resp.text}"

        if kind == "comm":
            raise CommunicationError(f"rest-api connection to {status_url}")

        raise RuntimeError(f"Unable to query deployment status {status_url}{details}")

    def check_limit_status(self):
        q = gql.gql(
            """
            query QueryLimitStatus($id: bigint!) {
                deployment(where: {id: {_eq: $id}}) {
                    id
                    deployed
                    limit_status
                }
            }
            """
        )

        variables = {"id": self.id()}
        assert self.client is not None
        res = self.client._gql_client.execute(q, variable_values=variables)[
            "deployment"
        ]
        if len(res) > 0:
            status = res[0]
            if "limit_status" in status:
                limit_status = status["limit_status"]
                if limit_status is not None:
                    raise LimitError(limit_status)

    def _wait_for(
        self,
        poll_fn: Callable[[], Tuple[bool, str, str]],
        task_name: str,
        on_iter: Callable[[int], None] = lambda ix: None,
        timeout: Optional[int] = None,
    ) -> "Deployment":
        """Wait for a generic task to finish before completing.

        Will wait up "timeout_request" seconds for the deployment to enter that state. This is set


        :return: The deployment, for chaining.
        :rtype: Deployment
        """
        assert self.client is not None
        warning = False
        duration = timeout if timeout is not None else self.client.timeout
        message = "(none)"
        kind = "unset"

        start = time.monotonic()
        ix = 0
        while ix == 0 or time.monotonic() - start < duration:
            on_iter(ix)
            ix += 1

            res, message, kind = poll_fn()
            if res:
                if self.client._interactive:
                    sys.stdout.write(" ok\n")
                return self

            if self.client._interactive:
                if not warning:
                    sys.stdout.write(
                        f"Waiting for {task_name} - this will take up to {duration}s "
                    )
                    warning = True
                time.sleep(1)
                sys.stdout.write(".")
            else:
                time.sleep(1)

        if kind == "comm":
            raise CommunicationError(message)
        else:
            try:
                status: Optional[Dict[str, Any]] = self.status()
                message = f"{task_name.capitalize()} failed. See status for details."
            except:
                message = f"{task_name.capitalize()} did not finish within {duration}s."
                status = None
            raise WaitForError(message, status)

    def wait_for_running(self, timeout: Optional[int] = None) -> "Deployment":
        """Waits for the deployment status to enter the "Running" state.

        Will wait up "timeout_request" seconds for the deployment to enter that state. This is set
        in the "Client" object constructor. Will raise various exceptions on failures.

        :return: The deployment, for chaining.
        :rtype: Deployment
        """

        def check_limit(ix: int) -> None:
            # If this checks immediately, it will happen too soon for the deployment manager to
            # have cleared the limit_status column on the deployment and this will fail erroneously
            if ix > 5:
                self.check_limit_status()

        def check_for_running() -> Tuple[bool, str, str]:
            try:
                res = self.status()
                if res is not None and res["status"] == "Running":
                    return True, "", ""
                return False, "not running", "runtime"
            except CommunicationError as ex:
                # Connection may be coming up, try again
                return False, str(ex), "comm"
            except (EntityNotFoundError, RuntimeError) as ex:
                # Not found may switch to found, after a while. Retry it.
                return False, f"not found {ex}", "runtime"

        try:
            return self._wait_for(check_for_running, "deployment", check_limit, timeout)
        except WaitForError as ex:
            status = ex.status
            message = f"{str(ex)}\nStatus: {str(status)}"
            if status is not None and status.get("status") == "Error":
                quantity, resource = None, None
                engines = status.get("engines", [])
                engine_lbs = status.get("engine_lbs", [])
                required_cpu = next(
                    filter(
                        lambda item: item.get("status") == "Pending"
                        and item.get("required_cpu"),
                        engines + engine_lbs,
                    ),
                    cast(Dict[str, Any], {}),
                ).get("required_cpu")
                if required_cpu:
                    resource = "CPU"
                    quantity = (
                        "one CPU"
                        if required_cpu == "1"
                        else f"{required_cpu} units of CPU"
                    )
                else:
                    required_memory = next(
                        filter(
                            lambda item: item.get("status") == "Pending"
                            and item.get("required_memory"),
                            engines + engine_lbs,
                        ),
                        cast(Dict[str, Any], {}),
                    ).get("required_memory")
                    if required_memory:
                        resource = "memory"
                        quantity = f"{required_memory} of memory"

                if quantity is not None and resource is not None:
                    message = (
                        "Cannot deploy pipeline due to insufficient resources. "
                        f"Your pipeline needs {quantity} to run but there is not enough {resource} currently available. "
                        "Please try again or un-deploy pipelines not in use to adjust the resources that are available for your Wallaroo instance. "
                        "Contact your Wallaroo platform administrator for additional support."
                    )

            raise WaitForDeployError(message)

    def wait_for_undeployed(self) -> "Deployment":
        """Waits for the deployment to end.

        Will wait up "timeout_request" seconds for the deployment to enter that state. This is set
        in the "Client" object constructor. Will raise various exceptions on failures.

        :return: The deployment, for chaining.
        :rtype: Deployment
        """

        def check_for_undeployed() -> Tuple[bool, str, str]:
            try:
                self.status()
                return False, "still running", "runtime"
            except CommunicationError as ex:
                # Connection may be coming up, try again
                return False, str(ex), "comm"
            except RuntimeError as ex:
                # Not found may switch to found, after a while. Retry it.
                return False, f"not found {ex}", "runtime"
            except EntityNotFoundError:
                return True, "", ""

        try:
            return self._wait_for(check_for_undeployed, "undeployment")
        except WaitForError as ex:
            message = f"{str(ex)}\nStatus: {str(ex.status)}"
            raise RuntimeError(message)

    def infer(
        self, tensor: Dict[str, Any], timeout: Optional[Union[int, float]] = None
    ) -> List[InferenceResult]:
        """Returns an inference result on this deployment.

        :param tensor Dict[str, Any]: Inference dictionary. Example:
            {
                "tensor": [
                    [
                        1.0678324729342086,
                        0.21778102664937624,
                        -1.7115145261843976,
                        0.6822857209662413,
                        1.0138553066742804,
                        -0.43350000129006655,
                        0.7395859436561657,
                        -0.28828395953577357,
                        -0.44726268795990787,
                        0.5146124987725894,
                        0.3791316964287545,
                        0.5190619748123175,
                        -0.4904593221655364,
                        1.1656456468728567,
                        -0.9776307444180006,
                        -0.6322198962519854,
                        -0.6891477694494687,
                        0.17833178574255615,
                        0.1397992467197424,
                        -0.35542206494183326,
                        0.4394217876939808,
                        1.4588397511627804,
                        -0.3886829614721505,
                        0.4353492889350186,
                        1.7420053483337175,
                        -0.4434654615252943,
                        -0.15157478906219238,
                        -0.26684517248765616,
                        -1.4549617756124493
                    ],
                ],
            }

        :param timeout Union[int, float]: infer requests will timeout after
            the amount of seconds provided are exceeded. timeout defaults
            to 15 secs.
        """
        if not isinstance(tensor, dict):
            raise TypeError(f"tensor is {type(tensor)} but 'dict' is required")
        if timeout is None:
            timeout = 15
        if not isinstance(timeout, (int, float)):
            raise TypeError(
                f"timeout is {type(timeout)} but 'int' or 'float' is required"
            )
        assert self.client is not None

        url = self._url()
        res = None
        try:
            res = self.session.post(
                url,
                json=tensor,
                timeout=timeout,
                # TODO: Digging the auth object out of the gql_client is cheating
                auth=self._get_auth(),
            )
            data = res.json()
        except (requests.exceptions.Timeout, requests.exceptions.ReadTimeout):
            raise RuntimeError(
                f"Inference did not return within {timeout}s, adjust if necessary"
            )
        except (requests.exceptions.RequestException, json.JSONDecodeError) as err:
            raise RuntimeError(f"Inference unable to complete.") from err
        return [InferenceResult(self._gql_client, d) for d in data]

    def infer_from_file(
        self,
        filename: Union[str, pathlib.Path],
        timeout: Optional[Union[int, float]] = None,
    ) -> List[InferenceResult]:
        if not isinstance(filename, pathlib.Path):
            filename = pathlib.Path(filename)
        with filename.open("rb") as f:
            tensor = json.load(f)
        return self.infer(tensor, timeout)

    async def batch_infer_from_file(
        self,
        filename: Union[str, pathlib.Path],
        data_key: str = "tensor",
        batch_size: int = 1000,
        connector_limit: int = 4,
    ) -> List[InferenceResult]:
        """Async method to run batched inference on a data file for a given deployment.

        :param str filename: path to an existing file with tensor data in JSON format.
        :param str data_key: key which the tensor data is under within the JSON. defaults to "tensor".
        :param int batch_size: batch size to use when sending requests to the engine. defaults to 1000.
        :param int connector_limit: limit for the amount of TCP connections. defaults to 4.
        :return: List of InferenceResult's.
        :rtype: List[InferenceResult]
        """
        if not isinstance(filename, pathlib.Path):
            filename = pathlib.Path(filename)
        with filename.open("rb") as f:
            json_data = orjson.loads(f.read())

        input_data = json_data[data_key]
        chunked_data = self._generate_chunk_data(input_data, batch_size, data_key)

        assert self.client is not None
        url = self._url()
        auth = self._get_auth()
        connector = aiohttp.TCPConnector(limit=connector_limit)

        headers = {}
        if isinstance(auth, _PlatformAuth):
            headers = auth.auth_header()

        async with aiohttp.ClientSession(
            connector=connector,
            headers=headers,
            json_serialize=lambda x: orjson.dumps(x).decode(),
        ) as session:
            requests = []
            for i, chunk in enumerate(chunked_data):
                requests.append(
                    asyncio.ensure_future(self._batch_infer(session, url, chunk))
                )

            resps = await asyncio.gather(*requests)
            return [InferenceResult(self._gql_client, resp) for resp in resps]

    def _chunk_data(self, data: Any, batch_size: int) -> Iterator[List[Any]]:
        for i in range(0, len(data), batch_size):
            yield data[i : i + batch_size]

    def _key_data(self, key: str, data: Any) -> Dict[str, Any]:
        return {key: data}

    def _generate_chunk_data(
        self, data: Dict[str, Any], batch_size: int, key: str
    ) -> Iterator[Dict[str, Any]]:
        chunked_data = self._chunk_data(data, batch_size)
        return (self._key_data(key, chunk) for chunk in chunked_data)

    async def _batch_infer(
        self, session: aiohttp.ClientSession, url: str, batch_data: Dict[str, Any]
    ):
        if not isinstance(batch_data, dict):
            raise TypeError(f"tensor is {type(batch_data)} but 'dict' is required")
        async with session.post(url, json=batch_data) as resp:
            resp_data = await resp.json(content_type=None)
            # NOTE: resp data comes back in a list, returning first elem for parity with requests resp
            return resp_data[0]

    def replace_model(self, model: "Model") -> "Deployment":
        """Replaces the current model with a default-configured Model.

        :param Model model: Model variant to replace current model with
        """
        return self.replace_configured_model(model.config())

    def replace_configured_model(self, model_config: ModelConfig) -> "Deployment":
        """Replaces the current model with a configured variant.

        :param ModelConfig model_config: Configured model to replace current model with
        """
        data = self._gql_client.execute(
            gql.gql(
                """
            mutation ReplaceModel($deployment_id: bigint!, $model_config_id: bigint!) {
                insert_deployment_model_configs(objects: {deployment_id: $deployment_id, model_config_id: $model_config_id}) {
                    returning {
                        id
                        deployment_id
                        model_config_id
                    }
                }
            }
        """
            ),
            variable_values={
                "deployment_id": self.id(),
                "model_config_id": model_config.id(),
            },
        )
        self._rehydrate()
        return self

    def internal_url(self) -> str:
        """Returns the internal inference URL that is only reachable from inside of the Wallaroo cluster by SDK instances deployed in the cluster.

        If both pipelines and models are configured on the Deployment, this
        gives preference to pipelines. The returned URL is always for the first
        configured pipeline or model.
        """
        return self._internal_url()

    def _internal_url(self) -> str:
        return (
            f"http://engine-lb.{self.name()}-{self.id()}:29502/pipelines/{self.name()}"
        )

    def url(self) -> str:
        """Returns the inference URL.

        If both pipelines and models are configured on the Deployment, this
        gives preference to pipelines. The returned URL is always for the first
        configured pipeline or model.
        """
        return self._url()

    def _url(self) -> str:
        if self.client is None:
            raise RuntimeError("api_endpoint must be provided to wallaroo.Client()")
        if "api-lb" in self.client.api_endpoint:
            return self._internal_url()

        return f"{self.client.api_endpoint}/v1/api/pipelines/infer/{self.name()}-{self.id()}"

    def logs(self, limit: int = 100, valid: Optional[bool] = None) -> LogEntries:
        """Deployment.logs() has been removed. Please use pipeline.logs() instead."""
        raise RuntimeError(
            "Deployment.logs() has been removed. Please use pipeline.logs() instead."
        )
