from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.assays_run_interactive_response_200_item_baseline_summary import (
    AssaysRunInteractiveResponse200ItemBaselineSummary,
)
from ..models.assays_run_interactive_response_200_item_summarizer_meta import (
    AssaysRunInteractiveResponse200ItemSummarizerMeta,
)
from ..models.assays_run_interactive_response_200_item_window_summary import (
    AssaysRunInteractiveResponse200ItemWindowSummary,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="AssaysRunInteractiveResponse200Item")


@attr.s(auto_attribs=True)
class AssaysRunInteractiveResponse200Item:
    """Assay result.

    Attributes:
        name (str):  Assay name.
        created_at (int):  Creation timestamp.
        elapsed_millis (int):  Milliseconds elapsed.
        pipeline_id (int):  Pipeline identifier.
        pipeline_name (str):  Pipeline name.
        iopath (str):  I/O path.
        baseline_summary (AssaysRunInteractiveResponse200ItemBaselineSummary):  Baseline summary.
        window_summary (AssaysRunInteractiveResponse200ItemWindowSummary):  Window summary.
        alert_threshold (float):  Alert threshold.
        score (float):  Score.
        scores (List[float]):  List of scores.
        summarizer_meta (AssaysRunInteractiveResponse200ItemSummarizerMeta):  Summarizer meta-data.
        status (str):  Result status.
        assay_id (Union[Unset, None, int]):  Assay identifier.
        warning_threshold (Union[Unset, None, float]):  Warning threshold.
        index (Union[Unset, None, int]):  Result index.
    """

    name: str
    created_at: int
    elapsed_millis: int
    pipeline_id: int
    pipeline_name: str
    iopath: str
    baseline_summary: AssaysRunInteractiveResponse200ItemBaselineSummary
    window_summary: AssaysRunInteractiveResponse200ItemWindowSummary
    alert_threshold: float
    score: float
    scores: List[float]
    summarizer_meta: AssaysRunInteractiveResponse200ItemSummarizerMeta
    status: str
    assay_id: Union[Unset, None, int] = UNSET
    warning_threshold: Union[Unset, None, float] = UNSET
    index: Union[Unset, None, int] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        created_at = self.created_at
        elapsed_millis = self.elapsed_millis
        pipeline_id = self.pipeline_id
        pipeline_name = self.pipeline_name
        iopath = self.iopath
        baseline_summary = self.baseline_summary.to_dict()

        window_summary = self.window_summary.to_dict()

        alert_threshold = self.alert_threshold
        score = self.score
        scores = self.scores

        summarizer_meta = self.summarizer_meta.to_dict()

        status = self.status
        assay_id = self.assay_id
        warning_threshold = self.warning_threshold
        index = self.index

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "created_at": created_at,
                "elapsed_millis": elapsed_millis,
                "pipeline_id": pipeline_id,
                "pipeline_name": pipeline_name,
                "iopath": iopath,
                "baseline_summary": baseline_summary,
                "window_summary": window_summary,
                "alert_threshold": alert_threshold,
                "score": score,
                "scores": scores,
                "summarizer_meta": summarizer_meta,
                "status": status,
            }
        )
        if assay_id is not UNSET:
            field_dict["assay_id"] = assay_id
        if warning_threshold is not UNSET:
            field_dict["warning_threshold"] = warning_threshold
        if index is not UNSET:
            field_dict["index"] = index

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        name = d.pop("name")

        created_at = d.pop("created_at")

        elapsed_millis = d.pop("elapsed_millis")

        pipeline_id = d.pop("pipeline_id")

        pipeline_name = d.pop("pipeline_name")

        iopath = d.pop("iopath")

        baseline_summary = AssaysRunInteractiveResponse200ItemBaselineSummary.from_dict(
            d.pop("baseline_summary")
        )

        window_summary = AssaysRunInteractiveResponse200ItemWindowSummary.from_dict(
            d.pop("window_summary")
        )

        alert_threshold = d.pop("alert_threshold")

        score = d.pop("score")

        scores = cast(List[float], d.pop("scores"))

        summarizer_meta = AssaysRunInteractiveResponse200ItemSummarizerMeta.from_dict(
            d.pop("summarizer_meta")
        )

        status = d.pop("status")

        assay_id = d.pop("assay_id", UNSET)

        warning_threshold = d.pop("warning_threshold", UNSET)

        index = d.pop("index", UNSET)

        assays_run_interactive_response_200_item = cls(
            name=name,
            created_at=created_at,
            elapsed_millis=elapsed_millis,
            pipeline_id=pipeline_id,
            pipeline_name=pipeline_name,
            iopath=iopath,
            baseline_summary=baseline_summary,
            window_summary=window_summary,
            alert_threshold=alert_threshold,
            score=score,
            scores=scores,
            summarizer_meta=summarizer_meta,
            status=status,
            assay_id=assay_id,
            warning_threshold=warning_threshold,
            index=index,
        )

        assays_run_interactive_response_200_item.additional_properties = d
        return assays_run_interactive_response_200_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
