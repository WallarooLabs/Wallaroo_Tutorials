from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="AssaysCreateJsonBodySummarizer")


@attr.s(auto_attribs=True)
class AssaysCreateJsonBodySummarizer:
    """Summarizer.

    Attributes:
        type (str):  Summarizer type.
        bin_mode (str):  Binning model.
        aggregation (str):  Aggregation.
        metric (str):  Metric.
        num_bins (int):  Number of bins.
        add_outlier_edges (bool):  Flag for adding outlier edges.
        bin_weights (Union[Unset, None, List[float]]):  Bin weights.
        bin_width (Union[Unset, None, List[float]]):
        provided_edges (Union[Unset, None, List[float]]):  Edge definitions.
    """

    type: str
    bin_mode: str
    aggregation: str
    metric: str
    num_bins: int
    add_outlier_edges: bool
    bin_weights: Union[Unset, None, List[float]] = UNSET
    bin_width: Union[Unset, None, List[float]] = UNSET
    provided_edges: Union[Unset, None, List[float]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = self.type
        bin_mode = self.bin_mode
        aggregation = self.aggregation
        metric = self.metric
        num_bins = self.num_bins
        add_outlier_edges = self.add_outlier_edges
        bin_weights: Union[Unset, None, List[float]] = UNSET
        if not isinstance(self.bin_weights, Unset):
            if self.bin_weights is None:
                bin_weights = None
            else:
                bin_weights = self.bin_weights

        bin_width: Union[Unset, None, List[float]] = UNSET
        if not isinstance(self.bin_width, Unset):
            if self.bin_width is None:
                bin_width = None
            else:
                bin_width = self.bin_width

        provided_edges: Union[Unset, None, List[float]] = UNSET
        if not isinstance(self.provided_edges, Unset):
            if self.provided_edges is None:
                provided_edges = None
            else:
                provided_edges = self.provided_edges

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
                "bin_mode": bin_mode,
                "aggregation": aggregation,
                "metric": metric,
                "num_bins": num_bins,
                "add_outlier_edges": add_outlier_edges,
            }
        )
        if bin_weights is not UNSET:
            field_dict["bin_weights"] = bin_weights
        if bin_width is not UNSET:
            field_dict["bin_width"] = bin_width
        if provided_edges is not UNSET:
            field_dict["provided_edges"] = provided_edges

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        type = d.pop("type")

        bin_mode = d.pop("bin_mode")

        aggregation = d.pop("aggregation")

        metric = d.pop("metric")

        num_bins = d.pop("num_bins")

        add_outlier_edges = d.pop("add_outlier_edges")

        bin_weights = cast(List[float], d.pop("bin_weights", UNSET))

        bin_width = cast(List[float], d.pop("bin_width", UNSET))

        provided_edges = cast(List[float], d.pop("provided_edges", UNSET))

        assays_create_json_body_summarizer = cls(
            type=type,
            bin_mode=bin_mode,
            aggregation=aggregation,
            metric=metric,
            num_bins=num_bins,
            add_outlier_edges=add_outlier_edges,
            bin_weights=bin_weights,
            bin_width=bin_width,
            provided_edges=provided_edges,
        )

        assays_create_json_body_summarizer.additional_properties = d
        return assays_create_json_body_summarizer

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
