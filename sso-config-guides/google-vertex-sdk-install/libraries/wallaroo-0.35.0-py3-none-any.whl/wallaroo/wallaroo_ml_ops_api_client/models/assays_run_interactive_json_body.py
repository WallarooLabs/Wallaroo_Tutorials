from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.assays_run_interactive_json_body_baseline import (
    AssaysRunInteractiveJsonBodyBaseline,
)
from ..models.assays_run_interactive_json_body_summarizer import (
    AssaysRunInteractiveJsonBodySummarizer,
)
from ..models.assays_run_interactive_json_body_window import (
    AssaysRunInteractiveJsonBodyWindow,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="AssaysRunInteractiveJsonBody")


@attr.s(auto_attribs=True)
class AssaysRunInteractiveJsonBody:
    """Request to run an assay interactively.

    Attributes:
        name (str):  Assay name.
        pipeline_id (int):  Pipeline identifier.
        pipeline_name (str):  Pipeline name.
        active (bool):  Indicates whether the assay is active.
        status (str):  Assay status.
        iopath (str):  Assay's I/O path.
        baseline (AssaysRunInteractiveJsonBodyBaseline):  Assay's baseline.
        window (AssaysRunInteractiveJsonBodyWindow):  Assay window.
        summarizer (AssaysRunInteractiveJsonBodySummarizer):  Summarizer.
        alert_threshold (float):  Alert threshold.
        workspace_id (int):  Workspace identifier.
        id (Union[Unset, None, int]):  Assay identifier.
        warning_threshold (Union[Unset, None, float]):  Optional warning threshold.
        run_until (Union[Unset, None, str]):  Optional end date and time.
        model_insights_url (Union[Unset, None, str]):  URL for model insights.
    """

    name: str
    pipeline_id: int
    pipeline_name: str
    active: bool
    status: str
    iopath: str
    baseline: AssaysRunInteractiveJsonBodyBaseline
    window: AssaysRunInteractiveJsonBodyWindow
    summarizer: AssaysRunInteractiveJsonBodySummarizer
    alert_threshold: float
    workspace_id: int
    id: Union[Unset, None, int] = UNSET
    warning_threshold: Union[Unset, None, float] = UNSET
    run_until: Union[Unset, None, str] = UNSET
    model_insights_url: Union[Unset, None, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        pipeline_id = self.pipeline_id
        pipeline_name = self.pipeline_name
        active = self.active
        status = self.status
        iopath = self.iopath
        baseline = self.baseline.to_dict()

        window = self.window.to_dict()

        summarizer = self.summarizer.to_dict()

        alert_threshold = self.alert_threshold
        workspace_id = self.workspace_id
        id = self.id
        warning_threshold = self.warning_threshold
        run_until = self.run_until
        model_insights_url = self.model_insights_url

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "pipeline_id": pipeline_id,
                "pipeline_name": pipeline_name,
                "active": active,
                "status": status,
                "iopath": iopath,
                "baseline": baseline,
                "window": window,
                "summarizer": summarizer,
                "alert_threshold": alert_threshold,
                "workspace_id": workspace_id,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if warning_threshold is not UNSET:
            field_dict["warning_threshold"] = warning_threshold
        if run_until is not UNSET:
            field_dict["run_until"] = run_until
        if model_insights_url is not UNSET:
            field_dict["model_insights_url"] = model_insights_url

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        name = d.pop("name")

        pipeline_id = d.pop("pipeline_id")

        pipeline_name = d.pop("pipeline_name")

        active = d.pop("active")

        status = d.pop("status")

        iopath = d.pop("iopath")

        baseline = AssaysRunInteractiveJsonBodyBaseline.from_dict(d.pop("baseline"))

        window = AssaysRunInteractiveJsonBodyWindow.from_dict(d.pop("window"))

        summarizer = AssaysRunInteractiveJsonBodySummarizer.from_dict(
            d.pop("summarizer")
        )

        alert_threshold = d.pop("alert_threshold")

        workspace_id = d.pop("workspace_id")

        id = d.pop("id", UNSET)

        warning_threshold = d.pop("warning_threshold", UNSET)

        run_until = d.pop("run_until", UNSET)

        model_insights_url = d.pop("model_insights_url", UNSET)

        assays_run_interactive_json_body = cls(
            name=name,
            pipeline_id=pipeline_id,
            pipeline_name=pipeline_name,
            active=active,
            status=status,
            iopath=iopath,
            baseline=baseline,
            window=window,
            summarizer=summarizer,
            alert_threshold=alert_threshold,
            workspace_id=workspace_id,
            id=id,
            warning_threshold=warning_threshold,
            run_until=run_until,
            model_insights_url=model_insights_url,
        )

        assays_run_interactive_json_body.additional_properties = d
        return assays_run_interactive_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
