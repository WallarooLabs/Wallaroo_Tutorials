from typing import Any, Dict, List, Type, TypeVar, cast

import attr

T = TypeVar("T", bound="AssaysRunInteractiveResponse200ItemBaselineSummary")


@attr.s(auto_attribs=True)
class AssaysRunInteractiveResponse200ItemBaselineSummary:
    """Baseline summary.

    Attributes:
        count (int):  Count.
        min_ (float):  Minimum.
        max_ (float):  Maximum.
        mean (float):  Mean.
        median (float):  Median.
        std (float):  Standard deviation.
        edges (List[float]):  Edges.
        edge_names (List[str]):  Edge names.
        aggregated_values (List[float]):  Aggregated values.
        aggregation (str):  Aggregation.
        start (str):  Start date and time.
        end (str):  End date and time.
    """

    count: int
    min_: float
    max_: float
    mean: float
    median: float
    std: float
    edges: List[float]
    edge_names: List[str]
    aggregated_values: List[float]
    aggregation: str
    start: str
    end: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        count = self.count
        min_ = self.min_
        max_ = self.max_
        mean = self.mean
        median = self.median
        std = self.std
        edges = self.edges

        edge_names = self.edge_names

        aggregated_values = self.aggregated_values

        aggregation = self.aggregation
        start = self.start
        end = self.end

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "count": count,
                "min": min_,
                "max": max_,
                "mean": mean,
                "median": median,
                "std": std,
                "edges": edges,
                "edge_names": edge_names,
                "aggregated_values": aggregated_values,
                "aggregation": aggregation,
                "start": start,
                "end": end,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        count = d.pop("count")

        min_ = d.pop("min")

        max_ = d.pop("max")

        mean = d.pop("mean")

        median = d.pop("median")

        std = d.pop("std")

        edges = cast(List[float], d.pop("edges"))

        edge_names = cast(List[str], d.pop("edge_names"))

        aggregated_values = cast(List[float], d.pop("aggregated_values"))

        aggregation = d.pop("aggregation")

        start = d.pop("start")

        end = d.pop("end")

        assays_run_interactive_response_200_item_baseline_summary = cls(
            count=count,
            min_=min_,
            max_=max_,
            mean=mean,
            median=median,
            std=std,
            edges=edges,
            edge_names=edge_names,
            aggregated_values=aggregated_values,
            aggregation=aggregation,
            start=start,
            end=end,
        )

        assays_run_interactive_response_200_item_baseline_summary.additional_properties = (
            d
        )
        return assays_run_interactive_response_200_item_baseline_summary

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
