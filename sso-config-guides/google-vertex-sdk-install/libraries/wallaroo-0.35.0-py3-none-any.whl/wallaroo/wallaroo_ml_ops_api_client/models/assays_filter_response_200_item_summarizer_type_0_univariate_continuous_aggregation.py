from enum import Enum


class AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousAggregation(
    str, Enum
):
    EDGES = "Edges"
    DENSITY = "Density"
    CUMULATIVE = "Cumulative"

    def __str__(self) -> str:
        return str(self.value)
