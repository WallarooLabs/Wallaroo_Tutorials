from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.assays_filter_response_200_item_summarizer_type_0_univariate_continuous_aggregation import (
    AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousAggregation,
)
from ..models.assays_filter_response_200_item_summarizer_type_0_univariate_continuous_bin_mode import (
    AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousBinMode,
)
from ..models.assays_filter_response_200_item_summarizer_type_0_univariate_continuous_metric import (
    AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousMetric,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="AssaysFilterResponse200ItemSummarizerType0UnivariateContinuous")


@attr.s(auto_attribs=True)
class AssaysFilterResponse200ItemSummarizerType0UnivariateContinuous:
    """Defines the summarizer/test we want to conduct

    Attributes:
        bin_mode (AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousBinMode):
        aggregation (AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousAggregation):
        metric (AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousMetric):  How we calculate the score
            between two histograms/vecs.  Add pct_diff and sum_pct_diff?
        num_bins (int):
        bin_weights (Union[Unset, None, List[float]]):
        provided_edges (Union[Unset, None, List[float]]):
    """

    bin_mode: AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousBinMode
    aggregation: AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousAggregation
    metric: AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousMetric
    num_bins: int
    bin_weights: Union[Unset, None, List[float]] = UNSET
    provided_edges: Union[Unset, None, List[float]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        bin_mode = self.bin_mode.value

        aggregation = self.aggregation.value

        metric = self.metric.value

        num_bins = self.num_bins
        bin_weights: Union[Unset, None, List[float]] = UNSET
        if not isinstance(self.bin_weights, Unset):
            if self.bin_weights is None:
                bin_weights = None
            else:
                bin_weights = self.bin_weights

        provided_edges: Union[Unset, None, List[float]] = UNSET
        if not isinstance(self.provided_edges, Unset):
            if self.provided_edges is None:
                provided_edges = None
            else:
                provided_edges = self.provided_edges

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bin_mode": bin_mode,
                "aggregation": aggregation,
                "metric": metric,
                "num_bins": num_bins,
            }
        )
        if bin_weights is not UNSET:
            field_dict["bin_weights"] = bin_weights
        if provided_edges is not UNSET:
            field_dict["provided_edges"] = provided_edges

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        bin_mode = (
            AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousBinMode(
                d.pop("bin_mode")
            )
        )

        aggregation = (
            AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousAggregation(
                d.pop("aggregation")
            )
        )

        metric = AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousMetric(
            d.pop("metric")
        )

        num_bins = d.pop("num_bins")

        bin_weights = cast(List[float], d.pop("bin_weights", UNSET))

        provided_edges = cast(List[float], d.pop("provided_edges", UNSET))

        assays_filter_response_200_item_summarizer_type_0_univariate_continuous = cls(
            bin_mode=bin_mode,
            aggregation=aggregation,
            metric=metric,
            num_bins=num_bins,
            bin_weights=bin_weights,
            provided_edges=provided_edges,
        )

        assays_filter_response_200_item_summarizer_type_0_univariate_continuous.additional_properties = (
            d
        )
        return assays_filter_response_200_item_summarizer_type_0_univariate_continuous

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
