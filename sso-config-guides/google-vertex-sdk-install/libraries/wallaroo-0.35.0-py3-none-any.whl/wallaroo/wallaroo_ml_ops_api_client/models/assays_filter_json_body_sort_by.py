from enum import Enum


class AssaysFilterJsonBodySortBy(str, Enum):
    CREATIONDATEASC = "CreationDateAsc"
    LASTRUNDATEASC = "LastRunDateAsc"

    def __str__(self) -> str:
        return str(self.value)
