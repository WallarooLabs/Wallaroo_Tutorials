import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.assays_filter_json_body_drift_detected import (
    AssaysFilterJsonBodyDriftDetected,
)
from ..models.assays_filter_json_body_sort_by import AssaysFilterJsonBodySortBy
from ..types import UNSET, Unset

T = TypeVar("T", bound="AssaysFilterJsonBody")


@attr.s(auto_attribs=True)
class AssaysFilterJsonBody:
    """
    Attributes:
        workspace_id (int):
        pipeline_id (Union[Unset, None, int]):
        name (Union[Unset, None, str]):
        active (Union[Unset, None, bool]):
        start (Union[Unset, None, datetime.datetime]):
        end (Union[Unset, None, datetime.datetime]):
        sort_by (Union[Unset, None, AssaysFilterJsonBodySortBy]):
        drift_detected (Union[Unset, None, AssaysFilterJsonBodyDriftDetected]):  This is all temporary code to mock up
            the coming Assay changes so the frontend  can start work and so that we can try out the api and work out any
            issues with the  front end requirements.   The datastructures have been updated according to the changes we know
            we currently  need. However there is a good chance that they will change in the future.  Previously we'd use
            assays_list to get a list of assay configs and then assays_results  to get all of the AssayResults for a
            pipeline in a time window with a limit from plateau.  Which would return a large unwieldy number of assay
            results.   The main difference between the previous way of getting results is that we will first  query for
            configs with various attributes (pipeline, drift_detected, start, etc.). This will  return a config (which match
            the filter) with a child array of assay results ids. Then batches  of assay results can be requested to get
            details. This will result in more requests to the backend  but that is the tradeoff: more requests with smaller
            filtered responses vs fewer requests with  larger more encompassing responses.   Querying does not exactly match
            the front end requirements but is rather a superset of them so that  queries can be quickly changed as the front
            end requirements change. For example the front end mockups  combine active, paused and drift detected. Where in
            actually these really should be seperate (in the  backend). Consequently the front end will have to switch
            between sending {active: true} and  {drift_detcted: alert} as necessary. And change to {active: true,
            drift_detcted: alert} when/if that  need arises.   These data structures are all in this module because they
            will need to be consolidated and moved into  another shared library where the rest-api and model-insights can
            both the same definitions. Till then  we need to duplicate/triplicate the structs to avoid breaking the code
            until we are ready to make the  switch.
    """

    workspace_id: int
    pipeline_id: Union[Unset, None, int] = UNSET
    name: Union[Unset, None, str] = UNSET
    active: Union[Unset, None, bool] = UNSET
    start: Union[Unset, None, datetime.datetime] = UNSET
    end: Union[Unset, None, datetime.datetime] = UNSET
    sort_by: Union[Unset, None, AssaysFilterJsonBodySortBy] = UNSET
    drift_detected: Union[Unset, None, AssaysFilterJsonBodyDriftDetected] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        workspace_id = self.workspace_id
        pipeline_id = self.pipeline_id
        name = self.name
        active = self.active
        start: Union[Unset, None, str] = UNSET
        if not isinstance(self.start, Unset):
            start = self.start.isoformat() if self.start else None

        end: Union[Unset, None, str] = UNSET
        if not isinstance(self.end, Unset):
            end = self.end.isoformat() if self.end else None

        sort_by: Union[Unset, None, str] = UNSET
        if not isinstance(self.sort_by, Unset):
            sort_by = self.sort_by.value if self.sort_by else None

        drift_detected: Union[Unset, None, str] = UNSET
        if not isinstance(self.drift_detected, Unset):
            drift_detected = self.drift_detected.value if self.drift_detected else None

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "workspace_id": workspace_id,
            }
        )
        if pipeline_id is not UNSET:
            field_dict["pipeline_id"] = pipeline_id
        if name is not UNSET:
            field_dict["name"] = name
        if active is not UNSET:
            field_dict["active"] = active
        if start is not UNSET:
            field_dict["start"] = start
        if end is not UNSET:
            field_dict["end"] = end
        if sort_by is not UNSET:
            field_dict["sort_by"] = sort_by
        if drift_detected is not UNSET:
            field_dict["drift_detected"] = drift_detected

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        workspace_id = d.pop("workspace_id")

        pipeline_id = d.pop("pipeline_id", UNSET)

        name = d.pop("name", UNSET)

        active = d.pop("active", UNSET)

        _start = d.pop("start", UNSET)
        start: Union[Unset, None, datetime.datetime]
        if _start is None:
            start = None
        elif isinstance(_start, Unset):
            start = UNSET
        else:
            start = isoparse(_start)

        _end = d.pop("end", UNSET)
        end: Union[Unset, None, datetime.datetime]
        if _end is None:
            end = None
        elif isinstance(_end, Unset):
            end = UNSET
        else:
            end = isoparse(_end)

        _sort_by = d.pop("sort_by", UNSET)
        sort_by: Union[Unset, None, AssaysFilterJsonBodySortBy]
        if _sort_by is None:
            sort_by = None
        elif isinstance(_sort_by, Unset):
            sort_by = UNSET
        else:
            sort_by = AssaysFilterJsonBodySortBy(_sort_by)

        _drift_detected = d.pop("drift_detected", UNSET)
        drift_detected: Union[Unset, None, AssaysFilterJsonBodyDriftDetected]
        if _drift_detected is None:
            drift_detected = None
        elif isinstance(_drift_detected, Unset):
            drift_detected = UNSET
        else:
            drift_detected = AssaysFilterJsonBodyDriftDetected(_drift_detected)

        assays_filter_json_body = cls(
            workspace_id=workspace_id,
            pipeline_id=pipeline_id,
            name=name,
            active=active,
            start=start,
            end=end,
            sort_by=sort_by,
            drift_detected=drift_detected,
        )

        assays_filter_json_body.additional_properties = d
        return assays_filter_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
