from enum import Enum


class AssaysFilterJsonBodyDriftDetected(str, Enum):
    ALERT = "Alert"

    def __str__(self) -> str:
        return str(self.value)
