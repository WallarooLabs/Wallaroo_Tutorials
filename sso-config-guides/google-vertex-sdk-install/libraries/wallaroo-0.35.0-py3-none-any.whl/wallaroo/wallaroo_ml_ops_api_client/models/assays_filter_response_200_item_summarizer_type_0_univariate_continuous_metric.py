from enum import Enum


class AssaysFilterResponse200ItemSummarizerType0UnivariateContinuousMetric(str, Enum):
    MAXDIFF = "MaxDiff"
    SUMDIFF = "SumDiff"
    PSI = "PSI"

    def __str__(self) -> str:
        return str(self.value)
