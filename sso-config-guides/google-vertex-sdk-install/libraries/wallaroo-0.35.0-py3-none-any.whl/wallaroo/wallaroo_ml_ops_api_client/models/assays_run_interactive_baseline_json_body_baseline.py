from typing import Any, Dict, List, Type, TypeVar

import attr

from ..models.assays_run_interactive_baseline_json_body_baseline_fixed import (
    AssaysRunInteractiveBaselineJsonBodyBaselineFixed,
)

T = TypeVar("T", bound="AssaysRunInteractiveBaselineJsonBodyBaseline")


@attr.s(auto_attribs=True)
class AssaysRunInteractiveBaselineJsonBodyBaseline:
    """Assay's baseline.

    Attributes:
        fixed (AssaysRunInteractiveBaselineJsonBodyBaselineFixed):  Fixed configuration.
    """

    fixed: AssaysRunInteractiveBaselineJsonBodyBaselineFixed
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        fixed = self.fixed.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Fixed": fixed,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        fixed = AssaysRunInteractiveBaselineJsonBodyBaselineFixed.from_dict(
            d.pop("Fixed")
        )

        assays_run_interactive_baseline_json_body_baseline = cls(
            fixed=fixed,
        )

        assays_run_interactive_baseline_json_body_baseline.additional_properties = d
        return assays_run_interactive_baseline_json_body_baseline

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
