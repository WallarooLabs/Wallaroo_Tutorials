import logging
from typing import Any, Set

import numpy.typing as npt
import pandas as pd

from mac.config.inference import CustomInferenceConfig
from mac.inference import Inference
from mac.inference.creation import InferenceBuilder
from mac.types import InferenceData

logger = logging.getLogger(__name__)


class Postprocessor(Inference):
    """Postprocessor class."""

    @property
    def expected_model_types(self) -> Set[Any]:
        """Returns a set of model instance types that are expected by this inference.

        :return: A set of model instance types that are expected by this inference.
        """
        return {int}

    @Inference.model.setter  # type: ignore
    def model(self, model: int) -> None:
        """Sets the model on which the inference is calculated.

        :param model: A custom model instance on which the inference is calculated.

        :raises TypeError: If the model is not an instance of expected_model_types.
        """
        self._raise_error_if_model_is_wrong_type(model)
        self._model = model

    def _predict(self, input_data: InferenceData) -> InferenceData:
        """Calculates the inference on the given input data.
        This is the core function that each subclass needs to implement
        in order to calculate the inference.

        :param input_data: The input data on which the inference is calculated.
        Depending on the number of inputs of the model, the input data can be either a single
        numpy array or a dictionary of numpy arrays.

        :raises InferenceDataValidationError: If the input data is not valid.
        Ideally, every subclass should raise this error if the input data is not valid.

        :return: The output of the model. Depending on the number of outputs of the model,
        the output data can be either a single numpy array or a dictionary of numpy arrays.
        """
        logger.info(f"input_data: {input_data}")
        input_data["prediction"] = self.postprocess_data(input_data["variable"])
        input_data.pop("variable")
        logger.info(f"result: {input_data}")
        return input_data

    @staticmethod
    def postprocess_data(data: npt.NDArray) -> npt.NDArray:
        # if variables[x] < 0, replace with [0]
        data[data <= 0] = 0
        return data


class PostprocessorBuilder(InferenceBuilder):
    """Postprocessor builder class."""

    @property
    def inference(self) -> Postprocessor:
        """Returns an Inference subclass instance.
        This specifies the Inference instance to be used
        by create() to build additionally needed components."""
        return Postprocessor()

    def create(self, config: CustomInferenceConfig) -> Postprocessor:
        """Creates an Inference subclass and assigns a model to it.

        :param config: Inference configuration

        :return: Inference subclass
        """
        inference = self.inference
        inference.model = 1
        return inference
