from mac.inference.creation import InferenceBuilder
from mac.inference import Inference

class Builder1(InferenceBuilder):
    @property
    def inference(self) -> Inference:
        pass

    def create(self, model_path: str) -> Inference:
        pass

class Builder2(InferenceBuilder):
    @property
    def inference(self) -> Inference:
        pass

    def create(self, model_path: str) -> Inference:
        pass

