def complex_algorithm(input_number):
    result = 0
    result = input_number + 10 + 3.14 * 42 / 12
    return result